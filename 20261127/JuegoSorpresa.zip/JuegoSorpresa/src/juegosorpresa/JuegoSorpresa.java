/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package juegosorpresa;

/**
 *
 * @author mabardaji
 */
public class JuegoSorpresa {

    /**
     * Crear el joc de la ruleta
     * Comences amb 1000 � 
     * Demanar� quina aposta vols 
     * Demanes quants diners vols apostar
     * Es tira la bola
     * Calcula els guanys
     * Es sumen als diners de la cartera
     * Et demana si vols continuar o no
     * Si vols continuar i tens diners tornes al principi
     * En qualsevol altre cas, s'acaba el joc i mostres amb quants diners ten vas a casa.
     * 
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
 
    

    
}
    
